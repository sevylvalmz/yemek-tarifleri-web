package com.receipt.receipt.controller;

import com.receipt.receipt.dto.Receipt;



import java.util.List;
import java.util.Random;

public class ReceiptResponse {
    List<Receipt> receiptList;


    public List<Receipt> getReceiptList() {
        return receiptList;
    }

    public void setReceiptList(List<Receipt> receiptList) {
        this.receiptList = receiptList;

    }


}
