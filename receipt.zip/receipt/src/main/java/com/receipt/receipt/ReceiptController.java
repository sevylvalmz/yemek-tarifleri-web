package com.receipt.receipt.controller;

import com.receipt.receipt.dto.Receipt;
import com.receipt.receipt.service.ReceiptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class ReceiptController {


    @Autowired
    ReceiptService receiptService;

    @CrossOrigin
    @GetMapping("/receipt-list")
    public ReceiptResponse listReceipt(){

        return  receiptService.listReceipt();

    }

    @CrossOrigin
    @PostMapping("/receipt-save")
    public Boolean saveReceipt( @RequestBody ReceiptRequest receiptRequest){

        return receiptService.addReceipt(receiptRequest.getReceipt());

    }
    @DeleteMapping("/receipt-delete")
    public boolean deleteReceipt( @RequestParam int id){
        receiptService.deleteReceipt(id);

    return true;
    }

}


