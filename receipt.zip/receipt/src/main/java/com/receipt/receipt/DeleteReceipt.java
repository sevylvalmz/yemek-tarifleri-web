package com.receipt.receipt.controller;

import com.receipt.receipt.dto.Receipt;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
@Service
public class DeleteReceipt {
    List<Receipt> listReceipt = new ArrayList<>();
    int randomId;


    public List<Receipt> getListReceipt() {
        return listReceipt;
    }

    public void setListReceipt(List<Receipt> listReceipt) {
        this.listReceipt = listReceipt;
    }

    public int getRandomId() {
        return randomId;
    }

    public void setRandomId(int randomId) {
        this.randomId = randomId;
    }
}

