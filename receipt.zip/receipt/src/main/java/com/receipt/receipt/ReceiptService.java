package com.receipt.receipt.service;


import com.receipt.receipt.controller.ReceiptResponse;
import com.receipt.receipt.dto.Receipt;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class ReceiptService {
    List<Receipt>listReceipt = new ArrayList<>();
    Random rand =new Random();


    public Boolean addReceipt( Receipt receipt) {
        int rand_int2 = rand.nextInt(1000);
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
        String strDate = dateFormat.format(date);
        receipt.setDate(strDate);
         receipt.setId(rand_int2);
         listReceipt.add(receipt);


         return true;


    }
    public ReceiptResponse listReceipt(){
        ReceiptResponse receiptResponse = new ReceiptResponse();
        receiptResponse.setReceiptList(listReceipt);
        return receiptResponse;

    }
    public void deleteReceipt(int id) {
        int i =0;
        for (Receipt receipt : listReceipt){

            if(receipt.getId()== id) {
                listReceipt.remove(i);
            }
            i++;
        }


    }
}
