package com.receipt.receipt.controller;


import com.receipt.receipt.dto.Receipt;

public class ReceiptRequest {

    Receipt receipt;

    public Receipt getReceipt() {
        return receipt;
    }

    public void setReceipt(Receipt receipt) {
        this.receipt = receipt;
    }

}






