const searchIcon = document.getElementById('searchIcon')
const searhEngine = document.getElementById('searchEngine')


searchIcon.addEventListener('click', () => {
    searhEngine.classList.toggle('active')

})